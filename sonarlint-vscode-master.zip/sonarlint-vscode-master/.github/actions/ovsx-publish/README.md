ovsx-publish
============

After the main release process has succeeded, publish the promoted artifact to
[OpenVSX](https://open-vsx.org/extension/SonarSource/sonarlint-vscode).

Requires secret `OPENVSX_TOKEN` to contain a personal access token for the
owner of the SonarSource namespace on OpenVSX.
