vsce-publish
============

After the main release process has succeeded, publish the promoted artifact to 
[the Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=SonarSource.sonarlint-vscode).

Requires secret `VSCE_TOKEN` to contain a personal access token that has
publisher rights to the [SonarSource publisher account](https://marketplace.visualstudio.com/publishers/SonarSource).
