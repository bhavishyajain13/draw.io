function foo() {
  var i;
}
