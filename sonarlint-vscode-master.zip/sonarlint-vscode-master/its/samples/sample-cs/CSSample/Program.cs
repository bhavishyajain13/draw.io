﻿namespace CSSample
{
    public class Sample
    {
        public void DoSomething() { }
    }
}

