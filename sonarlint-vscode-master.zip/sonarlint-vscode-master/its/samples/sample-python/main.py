from mod import add

def main():
  add(1, 2)
  add(1)
