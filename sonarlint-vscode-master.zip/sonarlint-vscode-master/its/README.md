# Running tests locally

To run ITs on a development box, run from the root folder:

> npm i  
> npm run package  
> cd its  
> npm i  
> npm test  

Or just run `runits.sh` script from root folder. It will execute all commands above.
> ./runits.sh
