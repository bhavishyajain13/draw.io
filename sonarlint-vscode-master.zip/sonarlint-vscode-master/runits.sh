npm i
npm run package
cd its
npm i
npm test
